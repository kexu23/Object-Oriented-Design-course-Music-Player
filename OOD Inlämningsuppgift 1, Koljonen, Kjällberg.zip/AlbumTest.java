import static org.junit.Assert.*;

import java.util.*;

import org.junit.Test;

class AlbumTest {
	
	private Album c;
	private Album sub;
    private String xd;
    private String bruh;
	private SoundClip s;

    @Test
    void testgetAlbumName() {
        xd = new String("xdd");
        c = new Album(xd);
        assertEquals((String) "xdd",(String) c.getAlbumName(c));
    }
	@Test
	void testgetSongs() {
		c = new Album(xd);
		c.addSong(s);
		assertEquals((SoundClip) s,(Set<SoundClip>) c.getSongs(c));
	}
	@Test
	void testgetSubalbum() {
		c = new Album(xd);
		sub = new Album(bruh);
		c.addSubAlbum(sub);
		assertEquals((Album) sub,(Album) c.getSubAlbum(sub));
	}
	@Test
	void testaddandremoveSong() {
		c = new Album(xd);
		c.addSong(s);
        assertEquals((SoundClip) s,(Set<SoundClip>) c.getSongs(c));
		c.removeSong(s);
		assertEquals((Set<SoundClip>) null,(Set<SoundClip>) c.getSongs(c));
	}
	@Test
	void testaddandremoveSubalbum() {
		c = new Album(xd);
		c.addSubAlbum(sub);
		assertEquals((Album) sub,(Album) c.getSubAlbum(sub));
		c.removeSubAlbum(sub);
		assertEquals((Album) null,(Album) c.getSubAlbum(sub));
	}

}

