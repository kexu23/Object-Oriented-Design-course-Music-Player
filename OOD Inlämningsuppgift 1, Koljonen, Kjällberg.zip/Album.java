import java.util.*;

public class Album{
   
private Album parentAlbum;      // Creates the parent album

private String albumName;       // Creates the album name, set for songs, and a list for subalbums
private Set<SoundClip> songs;
private List<Album> subalbum;

    public Album(String name){  // Constructor for the Album
        albumName = name;
        songs = new HashSet<SoundClip>();
        subalbum = new ArrayList<Album>();
    }

    public void addSong(SoundClip file){    // Adds a song to an album and parentalbums
        songs.add(file);
        if(parentAlbum != null){
            parentAlbum.addSong(file);
        }

    }

    public void removeSong(SoundClip file){     // Removes a specific song from the album and parentalbums
        songs.remove(file);
        if(parentAlbum != null){
            parentAlbum.removeSong(file);
        }
        
    }

    public void addSubAlbum(Album album){       // Adds a subalbum into an album
        album.parentAlbum = this;
        subalbum.add(album);
    }

    public void removeSubAlbum(Album album){    // Removes a subalbum from an album
        subalbum.remove(album);
    }

    public String getAlbumName(Album album){               // Returns a specific album name
        return album.albumName;
    }
    
    public Set<SoundClip> getSongs(Album album) {          // Returns the set of songs in a specific album
        return album.songs;
    }

    public List<Album> getSubAlbum(Album album){           // Returns the list of subalbums in a specific album
        return album.subalbum;    
    }

    public boolean CheckSubAlbum(Album album){             // Checks if a specific album contains a subalbum
        if (getSubAlbum(album) != null){ 
            return true;}
        else{ return false; }
    }

}
