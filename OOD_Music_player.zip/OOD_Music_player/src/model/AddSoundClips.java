package model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import view.MusicOrganizerWindow;

public class AddSoundClips implements Command{
	
	Album album;
	Album parentAlbum;
	MusicOrganizerWindow view;
	SoundClip soundclip;
	List<SoundClip> list;
	Map<Album, Set<SoundClip>> addedClips;
	
	public AddSoundClips(Album parentAlbum, List<SoundClip> list, MusicOrganizerWindow view) {
		this.parentAlbum = parentAlbum;
		this.list = list;
		this.view = view;
		addedClips = new HashMap<>();
	}
	
	@Override
	public void execute() {
		updateSoundClips(parentAlbum);
		Set<SoundClip> setList = new HashSet<>(list);
		parentAlbum.addSongs(setList);
		view.onClipsUpdated();
	}

	@Override
	public void undo() {
		for(Album a:addedClips.keySet()) {
			a.removeSongs(addedClips.get(a));
			view.onClipsUpdated();
		}
	}
	
	private void updateSoundClips(Album album) {
		Set<SoundClip> diff = new HashSet<>(list);
		diff.removeAll(album.getAllSongs());
		addedClips.put(album, diff);
		if(album.getParentAlbum() != null) {
			updateSoundClips(album.getParentAlbum());
		}
	}

}
