package model;

import view.MusicOrganizerWindow;

public class AddSubAlbum implements Command {
	
	Album parentAlbum;
	MusicOrganizerWindow view;
	Album album;
	
	public AddSubAlbum(Album parentAlbum, MusicOrganizerWindow view, Album album) {
		this.parentAlbum = parentAlbum;
		this.view = view;
		this.album = album;
	}

	@Override
	public void execute() {
        parentAlbum.addSubAlbum(album);
        view.onAlbumAdded(parentAlbum,album);
           
	}

	@Override
	public void undo() {
		parentAlbum.removeSubAlbum(album);
		view.onAlbumRemoved(album);
	}
	
}
