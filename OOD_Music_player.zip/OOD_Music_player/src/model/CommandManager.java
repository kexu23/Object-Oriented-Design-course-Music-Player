package model;

import java.util.Stack;

public class CommandManager {
	
	private static CommandManager instance = null;
    private Stack<Command> stackNormal;
    private Stack<Command> stackReverse;


    public static CommandManager getInstance(){
        if(instance != null)
            return instance;
        return new CommandManager();
    }

    private CommandManager() {
    	stackNormal = new Stack<>();
    	stackReverse = new Stack<>();
        
    }

    public void execute(Command actionList){
    	actionList.execute();
        stackNormal.push(actionList);
        view.ButtonPaneHBox.undoButton.setDisable(false);
               
    }

    public void undo() {
    	if(stackNormal.size() == 1) {
            view.ButtonPaneHBox.undoButton.setDisable(true);
    	}
        Command c = stackNormal.pop();
        c.undo();
        stackReverse.push(c);
        view.ButtonPaneHBox.redoButton.setDisable(false);
    }

    public void redo() {
    	if(stackReverse.size() == 1) {
            view.ButtonPaneHBox.redoButton.setDisable(true);
    	}
        Command c = stackReverse.pop();
        c.execute();
        stackNormal.push(c);
    }

    public void clearNormal() {
    	stackNormal.clear();
    }

    public void clearReverse() {
    	stackReverse.clear();
    }

}
