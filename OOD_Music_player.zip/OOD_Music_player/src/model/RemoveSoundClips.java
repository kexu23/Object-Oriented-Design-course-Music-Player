package model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import view.MusicOrganizerWindow;

public class RemoveSoundClips implements Command{
	
	Album album;
	Album parentAlbum;
	MusicOrganizerWindow view;
	SoundClip soundclip;
	List<SoundClip> list;
	Map<Album, Set<SoundClip>> removedClips;
	
	public RemoveSoundClips(Album parentAlbum, List<SoundClip> list, MusicOrganizerWindow view) {
		this.parentAlbum = parentAlbum;
		this.list = list;
		this.view = view;
		removedClips = new HashMap<>();
	}

	@Override
	public void execute() {
		updateRemovedSongs(parentAlbum);
		Set<SoundClip> setList = new HashSet<>(list);
		parentAlbum.removeSongs(setList);
		view.onClipsUpdated();
	}

	@Override
	public void undo() { 
		for(Album a : removedClips.keySet()) {
			a.addSongs(removedClips.get(a));
		}
		view.onClipsUpdated();
	}
	
	private void updateRemovedSongs(Album album) {
		Set<SoundClip> diff = new HashSet<>(list); //diff contains songs that will be removed
        if(album.contains(diff)) {
            removedClips.put(album, diff);
        }
        for(Album a:album.getSubAlbums()) {
            updateRemovedSongs(a);
        }
    }

}
